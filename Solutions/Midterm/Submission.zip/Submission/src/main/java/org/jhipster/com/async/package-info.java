/**
 * Async helpers.
 */
package org.jhipster.com.async;

/**
 * Swagger api specific code.
 */
package org.jhipster.com.config.apidoc;
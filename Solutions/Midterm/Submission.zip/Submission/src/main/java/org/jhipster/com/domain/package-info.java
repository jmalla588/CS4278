/**
 * JPA domain objects.
 */
package org.jhipster.com.domain;

/**
 * Spring Data ElasticSearch repositories.
 */
package org.jhipster.com.repository.search;

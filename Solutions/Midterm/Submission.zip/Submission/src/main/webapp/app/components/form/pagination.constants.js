(function() {
    'use strict';

    angular
        .module('midtermApplicationApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
